            <div class="swiper-slide last-slide" style="background: white;">
                
              <div class="page-container">  
                <div class="panel-half panel-patrons">
                  <div class="panel-content">
                    <p style="color: black; width: 70%; top: 90px;">Well, dear patron, that's it so far! But new pages are coming in! <br>You could go back to the <a href="<?php echo site_url(); ?>/patrons/">patrons page</a> And other than that, you could check out my <a href="https://www.pinterest.com/cherrorist/" target="_blank">Pinterest page</a>, and follow me or Thurston on Twitter: <br><a class="twitter-follow-button" href="https://twitter.com/cherrorist" data-size="large">Follow @cherrorist</a><br><a class="twitter-follow-button" href="https://twitter.com/Thurst4Truth" data-size="large">Follow Thurston &lt;- do it!</a><br>
                    And remember, you can always reach me directly through <a href="https://www.patreon.com/moonandmonster" target="_blank">Patreon</a>
                      <span class="speech-bubble bubble-4" style="right: 140px; bottom: -70px;"></span>
                    </p>
                               
                  </div>
                </div>
              </div>
              
              
            </div>


<script>window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
    t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);
 
  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
  };
 
  return t;
}(document, "script", "twitter-wjs"));</script>
            