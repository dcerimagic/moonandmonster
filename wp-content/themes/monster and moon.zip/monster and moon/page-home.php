<?php get_header(); ?>

<div class="page-container">
  <div class="panel-half">
    <div class="panel-content">
      <p>OOOH, what A WEBSHITE! <br>WHAT COULD ONE DO <br>WITH such A WEBSHITE?
        <span class="speech-bubble bubble-2"></span>
      </p>
    </div>
  </div>
  <div class="panel-half">
    <div class="panel-content">
      <p>That's "website", <br>maisie. you could, say, <br><a href="<?php echo site_url(); ?>/comic/">Read the comic</a>, obviously, <br>provided you know <br>how to read
        <span class="speech-bubble bubble-3"></span>
      </p>
    </div>
  </div>
  <div class="panel-half">
    <div class="panel-content">
      <p>Oh, fuck you, Leia! <br>I was just <br>taking the piss!
        <span class="speech-bubble bubble-2"></span>
      </p>
      <p>Sure, fucking<br>hillarious..
        <span class="speech-bubble bubble-3"></span>
      </p>
    </div>
  </div>
  <div class="panel-half">
    <div class="panel-content">
      <p>Ladies!  <br>Language, please! <br>We have a visitor!
        <span class="speech-bubble bubble-3"></span>
      </p>
    </div>
  </div>
  <div class="panel-half">
    <div class="panel-content">
      <p>Sorry about this. <br>Um.. So I'm the <br> Author, and..
        <span class="speech-bubble bubble-2"></span>
      </p>
      <p>Uh, like Leia said, you <br>could read Moon & Monster <br><a href="<?php echo site_url(); ?>/comic/">starting from the beginning</a>,  <br>I guess, or if you've  <br>already read some, You <br>can click on the menu <br>at the top and jump to a <br>certain chapter you know..
        <span class="speech-bubble bubble-4"></span>
      </p>
    </div>
  </div>
  <div class="panel-half">
    <div class="panel-content">
      <p>Fuck reading! Just go <br>to our Patreon page <br>and <a href="https://www.patreon.com/moonandmonster" target="_blank">give us money!</a> <br>Click that link! <br>Come on, click it!
        <span class="speech-bubble bubble-4"></span>
        <a href="https://www.patreon.com/moonandmonster" target="_blank" class="speech-bubble bubble-link">CLICK IT!!!</a>
      </p>
    </div>
  </div>
  <div class="panel-half">
    <div class="panel-content">
      <p>Don't be rude, Thurston, <br>that's our audience! <br>Now, I'm obligated by <br>contract to say that <br>Patrons get to read <br>everyting before anybody <br>else, get extra content <br>like deleted scenes, <br>CBR downloads and..
        <span class="speech-bubble bubble-3"></span>
      </p>
      <p>Fuck do I care?  <br>He's not paying <br>me anyway!
        <span class="speech-bubble bubble-1"></span>
      </p>
    </div>
  </div>
  <div class="panel-half">
    <div class="panel-content">
      <p>I'm not paying you <br>Because you don't exist. <br> <br>So let's.. you know, <br>ignore you.
        <span class="speech-bubble bubble-2"></span>
      </p>
      <p>Anyway! You can also <br>Follow me on twitter <br>
       <a class="twitter-follow-button" href="https://twitter.com/cherrorist" data-size="large">Follow @cherrorist</a> <br> and check out my <br>Pinterest page: <br>
       <a href="https://www.pinterest.com/cherrorist/" target="_blank">boreds by Denis <span class="c">C</span></a>
        <span class="speech-bubble bubble-4"></span>
      </p>
    </div>
  </div>
  <div class="panel-half">
    <div class="panel-content">
      <p>Which is all boring <br>and they should follow me: <br> 
       <a class="twitter-follow-button" href="https://twitter.com/Thurst4Truth" data-size="large">Follow Thurston &lt;- do it!</a><br>I have more followers,<br>anyway. Because <br>I'm. not. boring.
        <span class="speech-bubble bubble-3"></span>
      </p>
      <p>Shut up, Thurston, or I'll <br>fucking erase you, I swear <br>to God I will!
        <span class="speech-bubble bubble-2"></span>
      </p>
    </div>
  </div>
  <div class="panel-half">
    <div class="panel-content">
      <p>Right, right, I'm <br>leaving.. jeez..
        <span class="speech-bubble bubble-4"></span>
      </p>
      <p>Seriously..
        <span class="speech-bubble bubble-1"></span>
      </p>
    </div>
  </div>
  <div class="panel-half">
    <div class="panel-content">
      <p>So.. you! Visitor! <br>Look, I'm sorry for all <br>this. It's just, you <br>caught us in a bad <br>time, is all..
        <span class="speech-bubble bubble-3"></span>
      </p>
      <p>Um, just click the menu, <br><a href="#top">It's all up there anyway</a>. <br>And.. I'm really sorry you <br>had to witness all that, so.. <br>You know, <a href="<?php echo site_url(); ?>/comic/">read the comic</a>, <br>do some stuff, click <br>around, whatever. And.. <br>Catch you later! <br>Bye bye!
        <span class="speech-bubble bubble-3"></span>
      </p>
    </div>
  </div>
</div>

<!--<p class="txt-center">A puddle comes from the Moon, lands in Spain.<br>Dysfunctional American family on a trip to Europe.<br>Moon is pissed. </p>-->
<div class="full">
  <p class="txt-center"><small><sup>&copy;</sup>2013-2016, Denis <span class="c">C</span>. all rights reserved. <a href="<?php echo site_url(); ?>/credits/">Credits</a></small></p>
</div>


<script>window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
    t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);
 
  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
  };
 
  return t;
}(document, "script", "twitter-wjs"));</script>
<?php get_footer(); ?>