<?php get_header(); ?>

<div class="page-container">  
  <div class="panel-half">
    <div class="panel-content">
      <p>I'm not paying you <br>Because you don't exist. <br> <br>So let's.. you know, <br>ignore you.
        <span class="speech-bubble bubble-2"></span>
      </p>
      <p>Anyway! You can also <br>Follow me on twitter <br>
       <a class="twitter-follow-button" href="https://twitter.com/cherrorist" data-size="large">Follow @cherrorist</a> <br> and check out my <br>Pinterest page: <br>
       <a href="https://www.pinterest.com/cherrorist/" target="_blank">boreds by Denis <span class="c">C</span></a>
        <span class="speech-bubble bubble-4"></span>
      </p>
    </div>
  </div>
</div>
<?php get_footer(); ?>