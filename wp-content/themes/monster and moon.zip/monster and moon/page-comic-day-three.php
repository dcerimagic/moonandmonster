<?php get_header(); ?>
<div class="swiper-container">
        <div class="swiper-wrapper">
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_025_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_026_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_027_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_028_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_029_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_030_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_031_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_032_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_033_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_034_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_035_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_036_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_037_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_038_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_039_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_040_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_041_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_042_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_043_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_044_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_045_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_046_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_047_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_048_day3.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
        </div>
    </div>
    <div class="daynav-container">
        <a class="swiper-button-next" title="NEXT PAGE">&gt;</a>
        <a class="swiper-button-prev" title="PREVIOUS PAGE">&lt;</a>
        <a class="swiper-button-prev-page" href="<?php echo site_url(); ?>/comic-day-two/" title="PREVIOUS DAY">&lt;</a>
        <a class="swiper-button-next-page" href="<?php echo site_url(); ?>/comic-day-four/" title="NEXT DAY">&gt;</a>       
    </div>
<?php get_footer(); ?>