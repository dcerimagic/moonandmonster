<?php get_header(); ?>
<div class="swiper-container">
        <div class="swiper-wrapper">
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_075_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_076_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_077_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_078_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_079_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_080_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_081_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_082_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_083_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_084_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_085_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_086_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_087_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_088_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_089_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_090_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_091_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_092_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_093_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_094_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_095_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_096_day5.jpg" alt="Moon and Monster - online indie comic by Denis Ć. Day 5"></div>
        </div>
    </div>
    <div class="daynav-container">
        <a class="swiper-button-next" title="NEXT PAGE">&gt;</a>
        <a class="swiper-button-prev" title="PREVIOUS PAGE">&lt;</a>
        <a class="swiper-button-prev-page" href="<?php echo site_url(); ?>/comic-day-four/" title="PREVIOUS DAY">&lt;</a>
        <a class="swiper-button-next-page" href="<?php echo site_url(); ?>/comic-day-six/" title="NEXT DAY">&gt;</a>       
    </div>
<?php get_footer(); ?>