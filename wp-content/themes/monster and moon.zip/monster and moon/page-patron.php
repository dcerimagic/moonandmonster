<?php
/**
 * The template for displaying all single posts.
 * @package smtp2go
 */

get_header(); ?>


<?php the_content(); ?>


<?php
get_footer();
