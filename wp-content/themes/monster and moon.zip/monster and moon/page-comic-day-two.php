<?php get_header(); ?>
<div class="swiper-container">
        <div class="swiper-wrapper">
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_005_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_006_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_007_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_008_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_009_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_010_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_011_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_012_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_013_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_014_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_015_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_016_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_017_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_018_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_019_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_020_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_021_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_022_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_023_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_024_day2.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
        </div>
    </div>
    <div class="daynav-container">
        <a class="swiper-button-next" title="NEXT PAGE">&gt;</a>
        <a class="swiper-button-prev" title="PREVIOUS PAGE">&lt;</a>
        <a class="swiper-button-prev-page" href="<?php echo site_url(); ?>/comic/" title="PREVIOUS DAY">&lt;</a>
        <a class="swiper-button-next-page" href="<?php echo site_url(); ?>/comic-day-three/" title="NEXT DAY">&gt;</a>       
    </div>
<?php get_footer(); ?>