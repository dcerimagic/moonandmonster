<?php get_header(); ?>


<section class="single-content top-element">
<h1 class="txt-center">The neverending interview</h1>
<p>This is where I'll try to answer all the questions asked by my Patreon patrons, my readers, my characters, myself, and my mom. Hi mom!</p>
<p>So if you have a question or a comment and want to see yourself on this page, there's a couple of ways to do it:</p>
<p>    
    1:) <a href="" target="_blank">Get over to Patreon</a> and leave me a comment! If I like your comment, or your question, I'll draw an avatar based on your username, and punch in - and answer - your comment or question into this section!<br><br>
    2:) <a href="mailto:denis@moonandmonster.com">Email me</a> and there's a good chance your question will get featured! Cause well, you took the effort, and I do love talking to people :)
</p>
</section>



<?php get_footer(); ?>