<?php get_header(); ?>


<section class="single-content top-element">
<h1 class="txt-center">Credits</h1>
<p>Written, drawn colored and lettered by Denis <span class="c">C</span>.</p>
<p>In the very beginning I've discussed ideas and storyline over cups and cups of coffee at work with a friend called Stjepan Matau<span class="s small-s">s</span>i<span class="c small-c">c</span>. This comic evolved thanks to him.</p>
<p>Some of the brushes used for coloring were created by Sammy Wasabi.</p>
<p>Some of the color palettes used were created by manekineko, sugar!, GlueStudio, designjunkee, Sanguine, ginnysister, tvr, plamenj, davidgav, black.murder and L u n a.</p>
<p>Lettering is based on Burst my Bubble font by Kimberly Geswein.</p>
</section>



<?php get_footer(); ?>