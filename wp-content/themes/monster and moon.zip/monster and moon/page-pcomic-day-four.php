<?php get_header(); ?>
<div class="swiper-container">
        <div class="swiper-wrapper">
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_049_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_050_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_051_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_052_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_053_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_054_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_055_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_056_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_057_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_058_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_059_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_060_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_061_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_062_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_063_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_064_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_065_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_066_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_067_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_068_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_069_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_070_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_071_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_072_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_073_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
            <div class="swiper-slide"><img src="http://www.moonandmonster.com/wp-content/uploads/2016/05/mm_074_day4.jpg" alt="Moon and Monster - online indie comic by Denis Ć."></div>
        </div>
    </div>
    <div class="daynav-container">
        <a class="swiper-button-next" title="NEXT PAGE">&gt;</a>
        <a class="swiper-button-prev" title="PREVIOUS PAGE">&lt;</a>
        <a class="swiper-button-prev-page" href="<?php echo site_url(); ?>/pcomic-day-three/" title="PREVIOUS DAY">&lt;</a>
        <a class="swiper-button-next-page" href="<?php echo site_url(); ?>/pcomic-day-five/" title="NEXT DAY">&gt;</a>       
    </div>
<?php get_footer(); ?>